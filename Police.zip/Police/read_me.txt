Requirements 
 -need to lunch the index.html page through a server.
 -I used xampp for hosting a local server